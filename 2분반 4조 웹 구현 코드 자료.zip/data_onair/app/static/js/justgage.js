const scamProb = 0.8;

const guageValueDom = document.getElementById('gauge-value');

guageValueDom.innerText = `${scamProb}`;


alert('hi');


webix.ui({
    view:"justgage-chart",
    value:25,
    title:"Positive",
    height:300,
    min: 0,
    max: 100
});
